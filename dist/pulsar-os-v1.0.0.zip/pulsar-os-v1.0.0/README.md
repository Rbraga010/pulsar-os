# Pulsar OS v1.0

O instituto da sua empresa em um zip. CEO digital, secretária executiva e seis VPs com skills, memória contínua e curadoria de método. Tudo conectado ao seu Telegram. Instala numa VPS sua com um prompt no Claude Code.

## Pré-requisitos
- VPS Linux (Ubuntu 22+) com root SSH
- Claude Code instalado (assinatura Max)
- 2 bots no @BotFather (vamos criar juntos no passo 3)
- ~5GB livres

## Instalação em 4 passos (12-18 minutos)

1. **Descompacte** este zip na sua VPS:
   `unzip pulsar-os-v1.0.0.zip && cd pulsar-os-v1.0.0/`

2. **Provisão da infra** (10-15min, automatizado):
   `bash installer/install.sh`

3. **Crie os bots Telegram** (5min, guiado):
   `bash installer/bots/wizard.sh`

4. **Desperte o Pulse**:
   Cole o conteúdo de BOOTSTRAP-PROMPT.md no Claude Code.

Pulse vai entrar no seu Telegram, te entrevistar em 12-13 perguntas, gerar a CLAUDE.md da sua empresa, apresentar o time e propor a primeira missão.

## Estrutura
- `core/` — atualiza via git pull. Não modifique.
- `tenant/` — seu território. Pulse escreve aqui.
- `installer/` — scripts de provisão.

## Atualizações
v1.x: `git pull` no /core/. /tenant/ permanece intocado.

## Suporte
DIY: comunidade. Order bump (R$1.297): sessão 1h pós-compra.

## Licença
1 empresa por compra. Não revende. Detalhes em LICENSE.md.
