# PulsarH.AI · Design Guide

> **v1.0 · Half-Light** — Sistema oficial. Use este guia antes de propor qualquer artefato visual.

---

## 1 · Identidade

**PulsarH.AI** é um instituto premium de IA aplicada a marca, gestão e prospecção.

- **Posicionamento:** *Lidere com consciência. Amplifique com IA.*
- **Tom:** editorial, contemplativo, autoridade serena.
- **Não somos:** SaaS, agência, ferramenta. Somos **instituto** + **metodologia** + **amplificação por IA**.

### Os 3 pilares
| Pilar | O que é |
|-------|---------|
| **PULSAR** | O instituto. A curadoria humana. A consciência. |
| **H** | A metodologia (BMAD: Brand · Audit · Method · Action). |
| **AI** | A amplificação. Agentes, automação, escala. |

### Princípios
1. **Consciência antes de velocidade** — premium não tem pressa.
2. **Whitespace é luxo** — quando em dúvida, mais ar.
3. **Dourado é evento** — não decoração.

---

## 2 · Tipografia

### Stack
| Família | Função | Quando usar |
|---------|--------|-------------|
| **Fraunces** (serif) | Display editorial | Hero, h1–h2, KPIs, ênfase |
| **Sora** (sans display) | UI labels | Botões, sidebar, eyebrows |
| **Inter** (sans body) | Corpo | Parágrafos, descrições |
| **JetBrains Mono** | Técnico | Código, tokens, badges |

### Regras-mãe
- **Fraunces ≥ 18px sempre.** Weight 200 acima de 32px, weight 300 entre 18–32px. Abaixo disso fica ilegível.
- **Inter weight 350** como default no corpo. Line-height 1.7.
- **Sora weight 200–500** em UI. Letter-spacing negativo (–0.025em a –0.01em) em sizes grandes; neutro em UI.
- **Itálicos do Fraunces** são instinto editorial — use em palavras-chave do display: *"Lidere com consciência"*.
- **Mono** sempre uppercase com `letter-spacing: 0.1–0.2em` quando label; case original quando código.

### Escala
```
hero    → clamp(56px, 8vw, 120px)
h1      → 64px
h2      → 44px
h3      → 32px
h4      → 24px
body-lg → 18px
body    → 16px
small   → 14px
caption → 12px
micro   → 10px
```

---

## 3 · Cor

### Paleta
```
Navy      #0B0C1F deep | #121A2E base | #181A36 mid | #1F2245 soft
Violeta   #3B1750 deep | #5C4280 base | #7A5BA0 soft
Dourado   #C9A84A base | #B89C4A soft
Cream     #F2EFE6
Branco    #FFFFFF
Cinzas    #E8E9F0 / #A8AAC2 / #7B7E9E / #54577A / #383B5C
Semantic  success #4ADE80 | danger #E04D6C
```

### Regras de uso
| Cor | Use para | NUNCA em |
|-----|----------|----------|
| **Dourado** | CTA único da página, KPI principal, nav ativa, evento | Background pleno, ícones decorativos, múltiplos acentos |
| **Violeta** | Tags de IA, gradients de marca, símbolo, processo | Texto de corpo, botões neutros, BG em massa |
| **Navy** | Backgrounds, superfícies elevadas, containers | Texto sobre fundo claro com baixo contraste |
| **Cream** | Light mode, papel, PDFs, slides em sala iluminada | Backgrounds dark misturados |

> **Lei do dourado:** máximo 1 ocorrência por dobra. Dourado é evento, não decoração.

### Gradiente AI (oficial)
```css
linear-gradient(110deg, #5C4280 0%, #4A3270 35%, #2A2B5A 70%, #C9A84A 100%)
```
Sempre dessaturado. Mais cinza-violeta que púrpura. Dourado só nos últimos 15%.

---

## 4 · Espaçamento (sistema 8pt)

```
4 / 8 / 12 / 16 / 24 / 32 / 48 / 64 / 96 / 128 / 160 / 192
```

- **Padding hero:** 160px vertical
- **Gap entre seções:** 192px
- **Padding card:** 32–64px
- **Gap interno em grid:** 16–32px
- **Quando dúvida:** mais ar.

---

## 5 · Motion

```
easing:    cubic-bezier(0.16, 1, 0.3, 1)   /* expo-out */
fast:      200ms
base:      320ms
slow:      400ms
slower:    600ms
```

Premium nunca tem pressa. Default 320ms expo-out em hover, transições de estado, fade-ups. Sempre respeitar `prefers-reduced-motion`.

---

## 6 · Hairlines & Glow

### Bordas (sempre 0.5px com transparência)
```css
default: 0.5px solid rgba(255,255,255,0.08)
strong:  0.5px solid rgba(255,255,255,0.14)
gold:    0.5px solid rgba(201,168,74,0.25)
```

Nunca bordas sólidas pesadas. Hairlines criam estrutura sem peso.

### Glows (efeito tech sutil)
```css
gold:   0 0 24px rgba(201,168,74,0.35), 0 0 64px rgba(201,168,74,0.15)
violet: 0 0 32px rgba(122,91,160,0.35), 0 0 80px rgba(92,66,128,0.18)
```

---

## 7 · Voice & Tone

### Como falamos
- Confiante sem arrogância
- Editorial sem ser distante
- Técnico sem ser frio
- Português brasileiro, frases curtas
- Itálicos para ênfase no display, não em corpo

### Vocabulário PulsarH
| Use | Evite |
|-----|-------|
| consciência | mindset |
| amplificação | next-level |
| diagnóstico | análise express |
| instituto | startup |
| metodologia | framework |
| curadoria | seleção |

### Regras de copy
- ❌ **Sem emojis** (exceto pedido explícito do cliente)
- ❌ **Sem exclamação** em copy de produto
- ❌ **Sem clichês** de SaaS ("revolucione", "transforme sua vida")
- ✓ Itálicos no display em palavras-chave
- ✓ Eyebrows técnicos em mono uppercase: `01 · VISÃO`

---

## 8 · Componentes · matriz de decisão

### Quando usar
| Componente | Use quando | Não use quando | Alternativa |
|------------|------------|----------------|-------------|
| **Modal** | Decisão crítica, ação destrutiva, confirmação | Feedback rápido, info passageira | Toast ou Drawer |
| **Drawer** | Config rápida, detalhes laterais | Decisão crítica | Modal |
| **Toast** | Sucesso, erro reversível | Erro crítico | Modal ou inline alert |
| **Wizard** | Fluxo > 3 etapas (BMAD, onboarding) | Tarefa 1–2 cliques | Form único, tabs |
| **Command Palette** | Power users, navegação rápida | Usuário casual | Menu tradicional |

### Botões
- **Primário** (dourado): 1 por tela, sempre. CTA principal.
- **Secundário** (outline gold ou violeta soft): ações de suporte.
- **Ghost** (sem borda, hover sutil): ações terciárias.
- **Padding:** 14px × 28px. **Radius:** 4px. **Font:** Sora 500 com letter-spacing 0.04em.

### Cards
- **Background:** rgba(255,255,255,0.025) sobre navy.
- **Border:** hairline padrão.
- **Radius:** 16px ou 28px (xl).
- **Padding:** 32–64px conforme densidade.

---

## 9 · Acessibilidade (WCAG 2.1 AA mínimo)

| Critério | Como cumprimos |
|----------|----------------|
| **Contraste** | Branco/navy = 19.7:1 (AAA), gold/navy = 8.6:1 (AAA), text-3 light mode = 5.9:1 (AA) |
| **Foco visível** | Anel dourado 2px em qualquer focável via teclado |
| **Hit area** | 44px mínimo em mobile/touch (`@media pointer: coarse`) |
| **Motion** | Respeitar `prefers-reduced-motion` — sem animação se ativo |
| **Semântica** | HTML5 (`<section>`, `<nav>`, `<main>`), hierarquia heading, alt em imgs |

---

## 10 · Light Mode

Default é **dark**. Use **light** apenas em:
- ✓ PDFs e whitepapers para impressão
- ✓ Email templates corporativos
- ✓ Documentos financeiros, contratos
- ✓ Slides em sala iluminada

NUNCA usar light em:
- ✗ Hero da landing principal
- ✗ Pitch deck premium
- ✗ Avatar Pulsar (vórtice exige fundo escuro)

### Trocas no light
```
bg:      #0B0C1F → #F2EFE6
text:    #FFFFFF → #0B0C1F
text-2:  #A8AAC2 → #383B5C
border:  rgba(255,255,255,0.08) → rgba(11,12,31,0.10)
em:      gold     → violet-deep
```

---

## 11 · DO / DON'T (resumo)

### DO ✓
- Fraunces serif em display com itálicos para ênfase
- Dourado APENAS em CTA único e KPI principal
- Padding generoso, hairlines 0.5px com transparência
- Motion 320ms expo-out
- Dark mode default
- Acessibilidade WCAG AA mínimo
- Símbolo (vórtice) intacto

### DON'T ✗
- Fraunces em corpo longo
- Dourado em background pleno ou múltiplas vezes
- Gradientes saturados
- Weights pesados (600+) em display
- Motion rápido (<200ms)
- Modificar o vórtice
- Emojis sem pedido explícito
- Clichês de SaaS

---

## 12 · Naming

### Agentes de IA
Padrão: `Pulsar [Pilar/Função]`
- Pulsar Audit · análise interna
- Pulsar Brand · posicionamento
- Pulsar SDR · prospecção

### Releases
- **Major** v1.0 → mudança estrutural (codename obrigatório: *Half-Light*, *Pulsar Blue*, *Solar Edition*)
- **Minor** v1.1 → novos componentes
- **Patch** v1.0.1 → ajustes finos

---

## 13 · Tokens

Valores exatos em `pulsar-tokens.json`. Sempre puxe de lá em vez de inventar.

---

## 14 · Checklist antes de entregar

- [ ] Fraunces ≥ 18px em todo lugar?
- [ ] Dourado aparece **no máximo 1×** por dobra?
- [ ] Padding generoso (≥32px em cards, ≥160px em hero)?
- [ ] Hairlines 0.5px com transparência (não bordas sólidas)?
- [ ] Motion 320ms expo-out?
- [ ] Contrastes ≥ 4.5:1 (AA) em texto?
- [ ] Foco visível dourado em focáveis?
- [ ] Sem emojis, sem clichês de SaaS, sem exclamação?
- [ ] Símbolo (vórtice) intacto?
- [ ] Dark mode (a menos que contexto exija light)?

Se sim para todos — está PulsarH.AI.

---

*v1.0 · Half-Light · 2026*
