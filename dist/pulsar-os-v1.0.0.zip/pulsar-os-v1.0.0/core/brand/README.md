# PulsarH.AI · Agent Pack

Pacote pronto pra instalar o sistema de design da PulsarH.AI no seu agente de IA.

## Conteúdo

- **pulsar-design-guide.md** — Guia condensado em 14 capítulos. Leitura primária do agente.
- **pulsar-tokens.json** — Tokens estruturados (cores, fontes, espaçamento, motion).
- **pulsar-instructions.txt** — System prompt pronto + tutorial por plataforma.

## Instalação rápida

### Claude.ai (Project)
1. Crie um Project novo
2. Custom instructions: cole o bloco de instructions.txt
3. Project knowledge: upload dos 3 arquivos

### Cursor / Claude Code
1. Cole em `docs/design/` no seu repo
2. Crie `CLAUDE.md` na raiz apontando pro guide

### ChatGPT
1. Custom GPT → Configure
2. Cole instructions, upload dos arquivos no Knowledge

---

v1.0 · Half-Light · 2026
