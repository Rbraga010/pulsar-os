<!--
  Pulsar OS v1.0 — Interview Tree
  Arvore de 12 perguntas obrigatorias + 1 ramo opcional de personalizacao de identidade dos agents.
  Cobre 100% dos slots {{tenant.X}} do CLAUDE.md.template (direta ou derivada/install).
  Pulse executa via state machine pipeline_runs.

  Regras:
  - Cada resposta vai pra tenant/onboarding-answers.json (chave dot-notation).
  - /skip preenche [a entrevistar].
  - /pausa muda state pra awaiting_user.
  - Validacao falha = Pulse repete a pergunta UMA vez, depois aceita o que veio (com flag review-needed).
-->

# Interview Tree — 12 perguntas + ramo opcional de overrides

Total slots no template: 25
Slots preenchidos pelo installer (vps_ip, db_host, db_url, repo_path, vercel_team, bots.pulseh, bots.donna): 7
Slots a coletar via entrevista: 18 → distribuidos em 12 perguntas (algumas combinam slots).

Pulse anuncia "P{n} de 12" no inicio de cada pergunta. Mantem ritmo. A cada 3 perguntas: mini-status "3 de 12. Vamos."

---

## P1 — Nome da empresa

- **Slot:** `tenant.empresa.nome` (alimenta tambem `tenant_slug`, `tenant_name`, `company_name`)
- **Pergunta:** "Qual o nome da sua empresa?"
- **Tipo:** free-text
- **Validacao:** 2-50 chars, sem URL
- **Skip:** nao (essencial pra render)
- **Proxima:** P2

## P2 — Dominio + tagline

- **Slots:** `tenant.empresa.dominio`, `tenant.empresa.tagline`
- **Pergunta:** "Qual o dominio principal (ex: minhaempresa.com.br) e qual a tagline em uma linha? Se nao tem tagline, manda so o dominio."
- **Tipo:** free-text multi-slot
- **Parser:** primeira linha ou primeiro token com ponto = dominio. Resto = tagline.
- **Skip:** parcial — dominio essencial, tagline opcional ([a entrevistar])
- **Proxima:** P3

## P3 — Founder (nome + bio)

- **Slots:** `tenant.founder.nome` (alimenta `founder_first_name`), `tenant.founder.bio`
- **Pergunta:** "Quem e o Founder e em 2-3 linhas, qual a sua trajetoria? Quanto tempo nesse negocio, como chegou aqui."
- **Tipo:** free-text 2-blocos
- **Parser:** primeira linha = nome. Resto = bio.
- **Validacao:** se bio < 30 chars Pulse cobra: "Mais detalhe, por favor — vou usar pra calibrar voz da marca."
- **Skip:** nome NAO. Bio sim — Pulse NUNCA inventa bio. Slot vai pra [a entrevistar] e Donna cobra T+24h.
- **Proxima:** P4

## P4 — ICP primario

- **Slot:** `tenant.icp.primary`
- **Pergunta:** "Quem e seu cliente principal hoje? Idade, perfil, dor que voce resolve. Uma frase."
- **Tipo:** free-text
- **Validacao:** 20-200 chars
- **Skip:** ok ([a entrevistar])
- **Proxima:** P5

## P5 — ICP secundario (condicional)

- **Slot:** `tenant.icp.secondary`
- **Condicao:** so dispara se P4 foi respondida (nao pulada)
- **Pergunta:** "Tem um segundo publico que voce ja vende, mesmo que menor? Se nao tem, manda 'nao'."
- **Tipo:** free-text ou "nao"
- **Skip:** ok (vira "nao aplicavel")
- **Proxima:** P6

## P6 — Produto principal + esteira

- **Slots:** `tenant.produtos.principal`, `tenant.produtos.lista`
- **Pergunta:** "Qual o produto principal (carro-chefe) e quais outros produtos compoem a esteira? Lista por linha, comecando pelo carro-chefe."
- **Tipo:** free-text multi-linha
- **Parser:** linha 1 = principal. Resto = lista (separada por virgula ou linha).
- **Skip:** parcial — principal essencial. Sem ele Pulse re-pergunta.
- **Proxima:** P7

## P7 — Equipe atual

- **Slot:** `tenant.equipe.headcount_humano`
- **Pergunta:** "Quantas pessoas trabalham com voce hoje (CLT, PJ, freela somados)? Se for so voce, manda 'solo'."
- **Tipo:** numero ou "solo"
- **Validacao:** 0-9999 ou "solo"
- **Skip:** ok (vira "[a entrevistar]")
- **Proxima:** P8

## P8 — Voz da marca + vocabulario

- **Slots:** `tenant.brand.voz`, `tenant.brand.vocabulario`
- **Pergunta:** "Como voce descreve a voz da sua marca em 3 adjetivos? Tem alguma palavra que voce usa muito ou evita usar? (ex: 'a gente' ao inves de 'voces')"
- **Tipo:** free-text 2-blocos
- **Parser:** linha 1 = voz. Resto = vocabulario.
- **Skip:** ok ambos ([a entrevistar])
- **Proxima:** P9

## P9 — URLs (war room + repo + LP)

- **Slots:** `tenant.urls.warroom`, `tenant.urls.repo`, `tenant.urls.lp`
- **Pergunta:** "Tres URLs, uma por linha: war room (se ja existe — senao pula), repo Github, landing page institucional."
- **Tipo:** free-text 3-linhas
- **Parser:** regex URL por linha; se vier so 1 ou 2, distribui pelos slots na ordem.
- **Validacao:** cada linha tem que casar regex `https?://` ou ser "pula".
- **Skip:** ok ([a entrevistar] em cada slot vazio — install supre warroom URL apos deploy)
- **Proxima:** P10

## P10 — Foco de inteligencia + concorrentes

- **Slots:** `tenant.foco_intel`, `tenant.concorrentes`
- **Pergunta:** "Que tipo de noticia voce quer que o Leo Dias (head de radar) monitore pra voce? E quais sao 2-3 concorrentes diretos que devo ficar de olho?"
- **Tipo:** free-text 2-blocos
- **Parser:** linha 1 = foco_intel. Resto = lista concorrentes.
- **Skip:** ok ([a entrevistar])
- **Proxima:** P11

## P11 — Email Git (deploy)

- **Slot:** `tenant.founder.git_email`
- **Pergunta:** "Qual email voce usa no Github? Vou configurar como autor dos commits — Vercel rejeita deploy se vier de outro email."
- **Tipo:** free-text email
- **Validacao:** regex email simples
- **Skip:** nao (essencial pra deploy funcionar; se /skip Pulse marca alerta vermelho pra Falconi resolver no install)
- **Proxima:** P12

## P12 — Dor atual (roteador da primeira missao)

- **Slot:** `tenant.dor_atual` (nao vai pro template — alimenta first-mission-router.md)
- **Pergunta:** "Ultima obrigatoria. Qual a dor numero um hoje? Marca uma:
  1. Vendo pouco / pipeline vazio
  2. To soterrado / nao escalo
  3. Preciso conteudo / Instagram morto
  4. Produto novo / nicho indefinido
  5. Time desalinhado
  6. Nao sei se to lucrando
  7. Outra (escreve em uma frase)"
- **Tipo:** choice 1-7 (7 abre free-text). Aceita combinacao "1 e 3" ou "1+3".
- **Parser:** classifica em 1+ buckets (ver `first-mission-router.md`). Default se ininteligivel: "outras".
- **Skip:** vai pra "outras" (Donna cobra em 24h).
- **Proxima:** P13 (ramo opcional)

## P13 — Personalizacao de identidade (OPCIONAL)

- **Saida:** `tenant/agents-config.json` (overrides aplicados ao default canonico no render)
- **Pergunta:** "Quer personalizar a inspiracao de algum agente do time? Por padrao:
  1. Pulseh — Tallis Gomes (CEO orquestrador)
  2. Donna — Donna Paulsen (Secretaria)
  3. Alfredo — Alfredo Soares (Comercial Marketing)
  4. Caio — Caio Carneiro (Comercial Vendas)
  5. Flavia — Flavia Lippi (Produtos)
  6. Falconi — Vicente Falconi (Ops)
  7. Simon — Simon Sinek (People)
  8. Dalio — Ray Dalio (Financeiro)

  Pode trocar ate 3. Manda no formato: '1: Steve Jobs; 3: Seth Godin'. Manda 'default' pra herdar tudo."
- **Tipo:** free-text estruturado OR "default"
- **Validacao:** "default" OR padrao `<num>: <nome>;` ate 3 vezes. Numero fora de 1-8 = re-pergunta.
- **Skip:** sim (= default)
- **Parsing:** mapeia numero -> slug (1=pulseh, 2=donna, 3=alfredo, 4=caio, 5=flavia, 6=falconi, 7=simon, 8=dalio). Pra cada par, dispara P13b.
- **Proxima:** P13b (loop por override) OU FIM se "default"

## P13b — Bio curta do override (loop, 1 por override declarado em P13)

- **Slot:** `agents-config.json -> agents[slug].identity.inspiration_bio_short`
- **Pergunta:** "Sobre {nome_inspiracao} no papel de {papel_pt}: em 1-2 frases, por que essa inspiracao? (Eu NUNCA invento — se preferir, manda 'pulse escreve' e eu monto bio publica generica baseada na figura, marcada como review-needed.)"
- **Tipo:** multiline (50-400 chars) OR "pulse escreve"
- **Validacao:** tamanho ou flag
- **Skip:** sim (= "pulse escreve" + review-needed)
- **Proxima:** P13b (proximo override) OU FIM

---

## FIM — gatilho do render

Quando ultimo P13b respondido (ou P13="default"), Pulse:

1. Confirma: "Pegou tudo. Vou montar o cerebro da casa em ~30s. Volta ja."
2. Reage com `tools` na ultima mensagem do Founder.
3. Dispara render-pipeline.md.

---

## Logica condicional

- Se P7 = "solo": pula nada, mas Pulse anota internamente que time inicial e 1 humano + IA.gentes.
- Se P9 retornar 0 URLs: marca slot warroom como "[gerado-no-install]" — installer preenche com `https://warroom.{dominio}` apos deploy.
- Se P3 bio < 30 chars apos cobranca: aceita o que veio com flag review-needed. Donna cobra refinamento na semana 1.
- Se Founder digitar /skip 5+ vezes: Pulse confronta uma vez: "Faltam X perguntas. Vamos ate o fim ou paro aqui?". Se /skip de novo, aceita e segue.
- Se P12 retorna 2+ codigos (ex: "1 e 3"): rota combinada no first-mission-router (ver Padaria do Ze como gabarito).

## Cobertura de slots vs CLAUDE.md.template (auditoria)

Slots cobertos por pergunta direta:
- empresa.nome (P1) | empresa.dominio (P2) | empresa.tagline (P2)
- founder.nome (P3) | founder.bio (P3) | founder.git_email (P11)
- icp.primary (P4) | icp.secondary (P5)
- produtos.principal (P6) | produtos.lista (P6)
- equipe.headcount_humano (P7)
- brand.voz (P8) | brand.vocabulario (P8)
- urls.warroom (P9) | urls.repo (P9) | urls.lp (P9)
- foco_intel (P10) | concorrentes (P10)

Slots cobertos por DERIVACAO automatica:
- `tenant_slug`: kebab-case de empresa.nome (P1)
- `tenant_name` / `company_name` / `founder_first_name`: derivam de P1 e P3

Slots cobertos pelo INSTALLER (Iniciativa 4 — placeholder ate la):
- `infra.vps_ip` | `infra.db_host` | `infra.db_url` | `infra.repo_path` | `infra.vercel_team`
- `bots.pulseh` | `bots.donna`

Identidade dos agents (CORE+TENANT, novo):
- `tenant/agents-config.json` — gerado a partir do default + overrides P13/P13b

Total: 18 slots de tenant cobertos via 12 perguntas, 7 pelo installer, identidade via P13. Cobertura 100% template + agents-config.
